import React, { useState } from "react";
import { motion } from "framer-motion";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { ChevronDown, ChevronUp } from "lucide-react";

const HISTORICAL_SEASONS = [
  { year: "2023-24", team: "LAL", gp: 71, ppg: 25.7, rpg: 7.3, apg: 8.3, spg: 1.3, bpg: 0.5, fg: "54.0", tp: "41.0" },
  { year: "2022-23", team: "LAL", gp: 55, ppg: 28.9, rpg: 8.3, apg: 6.8, spg: 0.9, bpg: 0.6, fg: "50.0", tp: "32.1" },
  { year: "2021-22", team: "LAL", gp: 56, ppg: 30.3, rpg: 8.2, apg: 6.2, spg: 1.3, bpg: 1.1, fg: "52.4", tp: "35.9" },
  { year: "2020-21", team: "LAL", gp: 45, ppg: 25.0, rpg: 7.7, apg: 7.8, spg: 1.1, bpg: 0.6, fg: "51.3", tp: "36.5" },
  { year: "2019-20", team: "LAL", gp: 67, ppg: 25.3, rpg: 7.8, apg: 10.2, spg: 1.2, bpg: 0.5, fg: "49.3", tp: "34.8", champ: true },
  { year: "2018-19", team: "LAL", gp: 55, ppg: 27.4, rpg: 8.5, apg: 8.3, spg: 1.3, bpg: 0.6, fg: "51.0", tp: "33.9" },
  { year: "2017-18", team: "CLE", gp: 82, ppg: 27.5, rpg: 8.6, apg: 9.1, spg: 1.4, bpg: 0.9, fg: "54.2", tp: "36.7" },
  { year: "2016-17", team: "CLE", gp: 74, ppg: 26.4, rpg: 8.6, apg: 8.7, spg: 1.2, bpg: 0.6, fg: "54.8", tp: "36.3" },
  { year: "2015-16", team: "CLE", gp: 76, ppg: 25.3, rpg: 7.4, apg: 6.8, spg: 1.4, bpg: 0.6, fg: "52.0", tp: "30.9", champ: true },
  { year: "2014-15", team: "CLE", gp: 69, ppg: 25.3, rpg: 6.0, apg: 7.4, spg: 1.6, bpg: 0.7, fg: "48.8", tp: "35.4" },
  { year: "2013-14", team: "MIA", gp: 77, ppg: 27.1, rpg: 6.9, apg: 6.3, spg: 1.6, bpg: 0.3, fg: "56.7", tp: "37.9" },
  { year: "2012-13", team: "MIA", gp: 76, ppg: 26.8, rpg: 8.0, apg: 7.3, spg: 1.7, bpg: 0.9, fg: "56.5", tp: "40.6", champ: true, mvp: true },
  { year: "2011-12", team: "MIA", gp: 62, ppg: 27.1, rpg: 7.9, apg: 6.2, spg: 1.9, bpg: 0.8, fg: "53.1", tp: "36.2", champ: true, mvp: true },
  { year: "2010-11", team: "MIA", gp: 79, ppg: 26.7, rpg: 7.5, apg: 7.0, spg: 1.6, bpg: 0.6, fg: "51.0", tp: "33.0" },
  { year: "2009-10", team: "CLE", gp: 76, ppg: 29.7, rpg: 7.3, apg: 8.6, spg: 1.6, bpg: 1.0, fg: "50.3", tp: "33.3", mvp: true },
  { year: "2008-09", team: "CLE", gp: 81, ppg: 28.4, rpg: 7.6, apg: 7.2, spg: 1.7, bpg: 1.1, fg: "48.9", tp: "34.4", mvp: true },
  { year: "2007-08", team: "CLE", gp: 75, ppg: 30.0, rpg: 7.9, apg: 7.2, spg: 1.8, bpg: 1.1, fg: "48.4", tp: "31.5" },
  { year: "2006-07", team: "CLE", gp: 78, ppg: 27.3, rpg: 6.7, apg: 6.0, spg: 1.6, bpg: 0.7, fg: "47.6", tp: "31.9" },
  { year: "2005-06", team: "CLE", gp: 79, ppg: 31.4, rpg: 7.0, apg: 6.6, spg: 1.6, bpg: 0.8, fg: "48.0", tp: "33.5" },
  { year: "2004-05", team: "CLE", gp: 80, ppg: 27.2, rpg: 7.4, apg: 7.2, spg: 2.2, bpg: 0.7, fg: "47.2", tp: "35.1" },
  { year: "2003-04", team: "CLE", gp: 79, ppg: 20.9, rpg: 5.5, apg: 5.9, spg: 1.6, bpg: 0.7, fg: "41.7", tp: "29.0" },
];

export default function SeasonTable({ liveData }) {
  const [showAll, setShowAll] = useState(false);

  const currentSeason = liveData?.current_season;
  const currentSeasonRow = currentSeason
    ? {
        year: currentSeason.season || "2024-25",
        team: "LAL",
        gp: currentSeason.games_played,
        ppg: currentSeason.ppg,
        rpg: currentSeason.rpg,
        apg: currentSeason.apg,
        spg: currentSeason.spg,
        bpg: currentSeason.bpg,
        fg: currentSeason.fg_pct,
        tp: currentSeason.three_pct,
        live: true,
      }
    : null;

  const allSeasons = currentSeasonRow
    ? [currentSeasonRow, ...HISTORICAL_SEASONS]
    : HISTORICAL_SEASONS;

  const displayed = showAll ? allSeasons : allSeasons.slice(0, 8);

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, delay: 0.3 }}
    >
      <Card className="overflow-hidden">
        <CardHeader className="pb-3">
          <CardTitle className="text-xl font-bold flex items-center gap-2">
            Season-by-Season Stats
            <span className="text-xs font-normal text-muted-foreground">Regular Season</span>
          </CardTitle>
        </CardHeader>
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow className="bg-muted/50">
                  <TableHead className="font-semibold text-foreground/80 w-24">Season</TableHead>
                  <TableHead className="font-semibold text-foreground/80">Team</TableHead>
                  <TableHead className="font-semibold text-foreground/80 text-right">GP</TableHead>
                  <TableHead className="font-semibold text-foreground/80 text-right">PPG</TableHead>
                  <TableHead className="font-semibold text-foreground/80 text-right">RPG</TableHead>
                  <TableHead className="font-semibold text-foreground/80 text-right">APG</TableHead>
                  <TableHead className="font-semibold text-foreground/80 text-right">SPG</TableHead>
                  <TableHead className="font-semibold text-foreground/80 text-right">FG%</TableHead>
                  <TableHead className="font-semibold text-foreground/80 text-right">3P%</TableHead>
                  <TableHead className="font-semibold text-foreground/80 text-center">Awards</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {displayed.map((s) => (
                  <TableRow
                    key={s.year}
                    className={`hover:bg-muted/30 transition-colors ${s.live ? "bg-primary/5 border-l-2 border-l-primary" : ""}`}
                  >
                    <TableCell className="font-medium text-foreground">
                      <span className="flex items-center gap-1.5">
                        {s.year}
                        {s.live && (
                          <span className="w-1.5 h-1.5 rounded-full bg-chart-4 animate-pulse" />
                        )}
                      </span>
                    </TableCell>
                    <TableCell>
                      <span className={`font-semibold ${s.team === "LAL" ? "text-primary" : s.team === "MIA" ? "text-chart-5" : "text-chart-3"}`}>
                        {s.team}
                      </span>
                    </TableCell>
                    <TableCell className="text-right text-muted-foreground">{s.gp}</TableCell>
                    <TableCell className="text-right font-semibold text-foreground">{s.ppg}</TableCell>
                    <TableCell className="text-right text-muted-foreground">{s.rpg}</TableCell>
                    <TableCell className="text-right text-muted-foreground">{s.apg}</TableCell>
                    <TableCell className="text-right text-muted-foreground">{s.spg}</TableCell>
                    <TableCell className="text-right text-muted-foreground">{s.fg}%</TableCell>
                    <TableCell className="text-right text-muted-foreground">{s.tp}%</TableCell>
                    <TableCell className="text-center">
                      <div className="flex items-center justify-center gap-1">
                        {s.champ && <Badge className="bg-primary/15 text-primary border-primary/25 text-[10px] px-1.5">🏆</Badge>}
                        {s.mvp && <Badge className="bg-secondary/15 text-secondary border-secondary/25 text-[10px] px-1.5">MVP</Badge>}
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
          <button
            onClick={() => setShowAll(!showAll)}
            className="w-full py-3 text-sm font-medium text-primary hover:bg-muted/30 transition-colors flex items-center justify-center gap-1 border-t border-border"
          >
            {showAll ? <>Show Less <ChevronUp className="w-4 h-4" /></> : <>Show All Seasons <ChevronDown className="w-4 h-4" /></>}
          </button>
        </CardContent>
      </Card>
    </motion.div>
  );
}