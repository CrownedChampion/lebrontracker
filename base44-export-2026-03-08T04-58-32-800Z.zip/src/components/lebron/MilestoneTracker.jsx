import React from "react";
import { motion } from "framer-motion";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { CheckCircle2, Circle } from "lucide-react";

const milestones = [
  { title: "NBA All-Time Scoring Leader", date: "Feb 7, 2023", desc: "Surpassed Kareem Abdul-Jabbar's 38,387 points", done: true },
  { title: "40,000 Career Points", date: "Mar 2, 2024", desc: "First player in NBA history to reach 40K points", done: true },
  { title: "10,000 Career Assists", date: "Jan 21, 2023", desc: "Joined the exclusive 10K assists club", done: true },
  { title: "10,000 Career Rebounds", date: "Dec 29, 2022", desc: "Only player with 10K pts, 10K reb, 10K ast", done: true },
  { title: "4th NBA Championship", date: "Oct 11, 2020", desc: "Won title with Lakers in the NBA Bubble", done: true },
  { title: "20 All-Star Selections", date: "Feb 2024", desc: "Record-tying All-Star appearances", done: true },
  { title: "Played with son Bronny", date: "Oct 22, 2024", desc: "First father-son duo to play together in NBA", done: true },
  { title: "45,000 Career Points", date: "TBD", desc: "Next major scoring milestone", done: false },
  { title: "5th NBA Championship", date: "TBD", desc: "Would tie Kobe Bryant", done: false },
];

export default function MilestoneTracker() {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, delay: 0.4 }}
    >
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="text-xl font-bold">Career Milestones</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="relative">
            {/* Timeline line */}
            <div className="absolute left-[11px] top-2 bottom-2 w-px bg-border" />

            <div className="space-y-4">
              {milestones.map((m, i) => (
                <motion.div
                  key={m.title}
                  initial={{ opacity: 0, x: -10 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ duration: 0.3, delay: 0.5 + i * 0.05 }}
                  className="flex items-start gap-3 relative"
                >
                  {m.done ? (
                    <CheckCircle2 className="w-6 h-6 text-primary shrink-0 bg-card" />
                  ) : (
                    <Circle className="w-6 h-6 text-muted-foreground/40 shrink-0 bg-card" />
                  )}
                  <div className={`flex-1 ${!m.done ? "opacity-50" : ""}`}>
                    <div className="flex items-center gap-2 flex-wrap">
                      <p className="font-semibold text-sm text-foreground">{m.title}</p>
                      <span className="text-[10px] text-muted-foreground bg-muted px-2 py-0.5 rounded-full">
                        {m.date}
                      </span>
                    </div>
                    <p className="text-xs text-muted-foreground mt-0.5">{m.desc}</p>
                  </div>
                </motion.div>
              ))}
            </div>
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
}