import React from "react";
import { motion } from "framer-motion";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, Cell } from "recharts";

const BASE_LEADERS = [
  { name: "Kareem", points: 38387, active: false },
  { name: "Karl Malone", points: 36928, active: false },
  { name: "Kobe", points: 33643, active: false },
  { name: "Jordan", points: 32292, active: false },
  { name: "Dirk", points: 31560, active: false },
  { name: "Wilt", points: 31419, active: false },
];

const CustomTooltip = ({ active, payload }) => {
  if (active && payload && payload.length) {
    return (
      <div className="bg-card border border-border rounded-lg p-3 shadow-xl">
        <p className="font-semibold text-foreground text-sm">{payload[0].payload.name}</p>
        <p className="text-primary font-bold">{payload[0].value.toLocaleString()} pts</p>
      </div>
    );
  }
  return null;
};

export default function ScoringChart({ liveData }) {
  const careerPoints = liveData?.career_points || 40474;

  const scoringLeaders = [
    { name: "LeBron", points: careerPoints, active: true },
    ...BASE_LEADERS,
  ].sort((a, b) => b.points - a.points);

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, delay: 0.35 }}
    >
      <Card>
        <CardHeader className="pb-2">
          <CardTitle className="text-xl font-bold">All-Time Scoring Leaders</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={scoringLeaders} layout="vertical" margin={{ left: 0, right: 20 }}>
                <XAxis type="number" hide />
                <YAxis
                  type="category"
                  dataKey="name"
                  width={85}
                  tick={{ fill: "hsl(230, 10%, 55%)", fontSize: 12, fontWeight: 500 }}
                  axisLine={false}
                  tickLine={false}
                />
                <Tooltip content={<CustomTooltip />} cursor={false} />
                <Bar dataKey="points" radius={[0, 6, 6, 0]} barSize={24}>
                  {scoringLeaders.map((entry) => (
                    <Cell
                      key={entry.name}
                      fill={entry.active ? "hsl(45, 100%, 55%)" : "hsl(230, 15%, 25%)"}
                    />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
}