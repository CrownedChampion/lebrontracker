import React from "react";
import { motion } from "framer-motion";
import { Crown, MapPin, Calendar, Ruler } from "lucide-react";

export default function PlayerHeader({ liveData }) {
  const lastGame = liveData?.last_game;

  return (
    <motion.div
      initial={{ opacity: 0, y: -20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.6 }}
      className="relative overflow-hidden rounded-2xl bg-gradient-to-br from-secondary/30 via-card to-card border border-border p-6 md:p-8"
    >
      <div className="absolute top-0 right-0 w-64 h-64 bg-primary/5 rounded-full blur-3xl -translate-y-1/2 translate-x-1/2" />
      <div className="absolute bottom-0 left-0 w-48 h-48 bg-secondary/10 rounded-full blur-3xl translate-y-1/2 -translate-x-1/2" />

      <div className="relative flex flex-col md:flex-row items-center gap-6 md:gap-10">
        {/* Player Image */}
        <div className="relative">
          <div className="w-32 h-32 md:w-40 md:h-40 rounded-2xl overflow-hidden border-2 border-primary/30 shadow-lg shadow-primary/10">
            <img
              src="https://cdn.nba.com/headshots/nba/latest/1040x760/2544.png"
              alt="LeBron James"
              className="w-full h-full object-cover object-top bg-muted"
            />
          </div>
          <div className="absolute -bottom-2 -right-2 bg-primary text-primary-foreground rounded-lg px-2.5 py-1 text-xs font-bold shadow-lg">
            #23
          </div>
        </div>

        {/* Player Info */}
        <div className="flex-1 text-center md:text-left">
          <div className="flex items-center justify-center md:justify-start gap-2 mb-1">
            <Crown className="w-5 h-5 text-primary" />
            <span className="text-primary text-sm font-semibold tracking-wider uppercase">The King</span>
          </div>
          <h1 className="text-4xl md:text-5xl font-black text-foreground tracking-tight">
            LeBron James
          </h1>
          <p className="text-muted-foreground mt-2 text-lg">
            Los Angeles Lakers · Small Forward
          </p>

          <div className="flex flex-wrap items-center justify-center md:justify-start gap-4 mt-4 text-sm text-muted-foreground">
            <div className="flex items-center gap-1.5">
              <Calendar className="w-4 h-4 text-primary/70" />
              <span>Born Dec 30, 1984</span>
            </div>
            <div className="flex items-center gap-1.5">
              <MapPin className="w-4 h-4 text-primary/70" />
              <span>Akron, Ohio</span>
            </div>
            <div className="flex items-center gap-1.5">
              <Ruler className="w-4 h-4 text-primary/70" />
              <span>6'9" · 250 lbs</span>
            </div>
          </div>

          <div className="flex flex-wrap items-center justify-center md:justify-start gap-2 mt-4">
            {["4x NBA Champion", "4x Finals MVP", "4x MVP", "20x All-Star"].map((badge) => (
              <span
                key={badge}
                className="px-3 py-1 rounded-full text-xs font-medium bg-primary/10 text-primary border border-primary/20"
              >
                {badge}
              </span>
            ))}
          </div>
        </div>

        {/* Last Game Box */}
        {lastGame && (
          <div className="hidden lg:flex flex-col items-center bg-muted/40 border border-border rounded-xl p-4 min-w-[160px] text-center">
            <p className="text-[10px] uppercase tracking-widest text-muted-foreground mb-2">Last Game</p>
            <p className="text-xs text-muted-foreground">{lastGame.date}</p>
            <p className="text-sm font-semibold text-foreground mt-1">vs {lastGame.opponent}</p>
            <p className="text-xs text-muted-foreground">{lastGame.result}</p>
            <div className="flex gap-3 mt-3 text-center">
              <div>
                <p className="text-xl font-black text-primary">{lastGame.points}</p>
                <p className="text-[10px] text-muted-foreground">PTS</p>
              </div>
              <div>
                <p className="text-xl font-black text-foreground">{lastGame.rebounds}</p>
                <p className="text-[10px] text-muted-foreground">REB</p>
              </div>
              <div>
                <p className="text-xl font-black text-foreground">{lastGame.assists}</p>
                <p className="text-[10px] text-muted-foreground">AST</p>
              </div>
            </div>
          </div>
        )}

        {!lastGame && (
          <div className="hidden lg:flex flex-col items-center">
            <span className="text-8xl font-black text-primary/10">23</span>
          </div>
        )}
      </div>
    </motion.div>
  );
}