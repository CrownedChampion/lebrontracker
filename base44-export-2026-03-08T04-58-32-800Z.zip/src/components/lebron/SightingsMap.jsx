import React, { useState, useEffect } from "react";
import { motion } from "framer-motion";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { MapPin, Clock, Eye } from "lucide-react";

const STATIC_SIGHTINGS = [
  {
    id: 2,
    location: "Nobu Restaurant, Malibu, CA",
    desc: "Dinner with family after practice",
    date: "Mar 3, 2026",
    lat: 34.0259,
    lng: -118.7798,
    emoji: "🍣",
  },
  {
    id: 3,
    location: "Beverly Hills, CA",
    desc: "Chilling at the crib, instagram story confirmed",
    date: "Feb 28, 2026",
    lat: 34.0736,
    lng: -118.4004,
    emoji: "🏠",
  },
  {
    id: 4,
    location: "LAX Airport, Los Angeles, CA",
    desc: "Boarding private jet, destination unknown",
    date: "Feb 22, 2026",
    lat: 33.9425,
    lng: -118.4081,
    emoji: "✈️",
  },
  {
    id: 5,
    location: "Chase Center, San Francisco, CA",
    desc: "Away game vs Golden State — 31 pts, 9 ast",
    date: "Feb 18, 2026",
    lat: 37.7679,
    lng: -122.3874,
    emoji: "🏀",
  },
  {
    id: 6,
    location: "SpringHill Company, Culver City, CA",
    desc: "Business meeting at his production company",
    date: "Feb 10, 2026",
    lat: 34.0211,
    lng: -118.3965,
    emoji: "💼",
  },
  {
    id: 7,
    location: "Akron, Ohio",
    desc: "Visited hometown for I PROMISE School event",
    date: "Jan 28, 2026",
    lat: 41.0814,
    lng: -81.5190,
    emoji: "🏫",
  },
];

export default function SightingsMap({ latestSighting }) {
  const [sightings, setSightings] = useState(STATIC_SIGHTINGS);
  const [selected, setSelected] = useState(null);

  // When a new live sighting arrives, prepend it and auto-select it
  useEffect(() => {
    if (latestSighting && latestSighting.location) {
      const liveSighting = {
        id: "live",
        location: latestSighting.location,
        desc: latestSighting.description,
        date: latestSighting.date,
        lat: latestSighting.lat,
        lng: latestSighting.lng,
        emoji: latestSighting.emoji || "📍",
        live: true,
      };
      setSightings([liveSighting, ...STATIC_SIGHTINGS]);
      setSelected(liveSighting);
    }
  }, [latestSighting]);

  // Default selected to first item on mount
  useEffect(() => {
    if (!selected) {
      setSightings((prev) => { setSelected(prev[0]); return prev; });
    }
  }, []);

  const current = selected || sightings[0];
  const appleMapsUrl = current
    ? `https://maps.apple.com/?q=${encodeURIComponent(current.location)}&ll=${current.lat},${current.lng}&z=14`
    : "";
  const osmEmbedUrl = current
    ? `https://www.openstreetmap.org/export/embed.html?bbox=${current.lng - 0.05},${current.lat - 0.03},${current.lng + 0.05},${current.lat + 0.03}&layer=mapnik&marker=${current.lat},${current.lng}`
    : "";

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, delay: 0.5 }}
    >
      <Card className="overflow-hidden">
        <CardHeader className="pb-3">
          <CardTitle className="text-xl font-bold flex items-center gap-2">
            <Eye className="w-5 h-5 text-primary" />
            LeBron Sightings
            <span className="ml-auto text-xs font-normal bg-primary/10 text-primary border border-primary/20 px-2 py-0.5 rounded-full">
              LIVE TRACKER
            </span>
          </CardTitle>
        </CardHeader>
        <CardContent className="p-0">
          <div className="flex flex-col lg:flex-row">
            {/* Sightings list */}
            <div className="lg:w-80 border-b lg:border-b-0 lg:border-r border-border overflow-y-auto max-h-80 lg:max-h-[420px]">
              {sightings.map((s) => (
                <button
                  key={s.id}
                  onClick={() => setSelected(s)}
                  className={`w-full text-left px-4 py-3 flex items-start gap-3 hover:bg-muted/40 transition-colors border-b border-border/50 last:border-0 ${
                    current?.id === s.id ? "bg-primary/10 border-l-2 border-l-primary" : ""
                  }`}
                >
                  <span className="text-xl shrink-0 mt-0.5">{s.emoji}</span>
                  <div className="min-w-0">
                    <div className="flex items-center gap-1.5">
                      <p className="text-sm font-semibold text-foreground truncate">{s.location}</p>
                      {s.live && <span className="w-1.5 h-1.5 rounded-full bg-chart-4 animate-pulse shrink-0" />}
                    </div>
                    <p className="text-xs text-muted-foreground mt-0.5 line-clamp-2">{s.desc}</p>
                    <div className="flex items-center gap-1 mt-1">
                      <Clock className="w-3 h-3 text-muted-foreground" />
                      <span className="text-[10px] text-muted-foreground">{s.date}</span>
                    </div>
                  </div>
                </button>
              ))}
            </div>

            {/* Map */}
            <div className="flex-1 flex flex-col">
              <div className="flex items-center gap-2 px-4 py-2 bg-muted/30 border-b border-border">
                <MapPin className="w-4 h-4 text-primary" />
                <span className="text-sm font-medium text-foreground truncate">{current?.location}</span>
                <a
                  href={appleMapsUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="ml-auto shrink-0 text-xs text-primary hover:underline"
                >
                  Open in Maps ↗
                </a>
              </div>
              {current && (
                <iframe
                  key={`${current.id}-${current.lat}-${current.lng}`}
                  title="Map Sighting"
                  width="100%"
                  height="380"
                  src={osmEmbedUrl}
                  style={{ border: 0 }}
                  allowFullScreen
                  className="w-full"
                />
              )}
            </div>
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
}