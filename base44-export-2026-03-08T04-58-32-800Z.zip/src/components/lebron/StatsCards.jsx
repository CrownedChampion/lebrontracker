import React from "react";
import { motion } from "framer-motion";
import { Target, Crosshair, Users, Trophy, TrendingUp, Flame } from "lucide-react";

export default function StatsCards({ liveData }) {
  const season = liveData?.current_season;
  const careerPoints = liveData?.career_points;

  const stats = [
    {
      label: "Career Points",
      value: careerPoints ? careerPoints.toLocaleString() : "40,474+",
      sub: "NBA All-Time Leader",
      icon: Target,
      color: "from-primary/20 to-primary/5",
      iconColor: "text-primary",
      borderColor: "border-primary/20",
    },
    {
      label: "PPG This Season",
      value: season ? season.ppg.toFixed(1) : "—",
      sub: season ? `${season.season} Season` : "Loading...",
      icon: TrendingUp,
      color: "from-chart-3/20 to-chart-3/5",
      iconColor: "text-chart-3",
      borderColor: "border-chart-3/20",
    },
    {
      label: "APG This Season",
      value: season ? season.apg.toFixed(1) : "—",
      sub: "Assists Per Game",
      icon: Users,
      color: "from-secondary/20 to-secondary/5",
      iconColor: "text-secondary",
      borderColor: "border-secondary/20",
    },
    {
      label: "RPG This Season",
      value: season ? season.rpg.toFixed(1) : "—",
      sub: "Rebounds Per Game",
      icon: Crosshair,
      color: "from-chart-3/20 to-chart-3/5",
      iconColor: "text-chart-3",
      borderColor: "border-chart-3/20",
    },
    {
      label: "Games Played",
      value: season ? season.games_played : "—",
      sub: season ? season.season : "This Season",
      icon: Flame,
      color: "from-chart-5/20 to-chart-5/5",
      iconColor: "text-chart-5",
      borderColor: "border-chart-5/20",
    },
    {
      label: "Championships",
      value: "4",
      sub: "CLE (2016), MIA (2x), LAL",
      icon: Trophy,
      color: "from-primary/20 to-primary/5",
      iconColor: "text-primary",
      borderColor: "border-primary/20",
    },
  ];

  return (
    <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3 md:gap-4">
      {stats.map((stat, i) => (
        <motion.div
          key={stat.label}
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.4, delay: i * 0.08 }}
          className={`relative overflow-hidden rounded-xl bg-gradient-to-b ${stat.color} border ${stat.borderColor} p-4 md:p-5`}
        >
          <stat.icon className={`w-5 h-5 ${stat.iconColor} mb-3 opacity-80`} />
          <p className="text-2xl md:text-3xl font-black text-foreground tracking-tight">
            {stat.value}
          </p>
          <p className="text-xs font-semibold text-foreground/70 mt-1">{stat.label}</p>
          <p className="text-[10px] text-muted-foreground mt-0.5 leading-tight">{stat.sub}</p>
        </motion.div>
      ))}
    </div>
  );
}