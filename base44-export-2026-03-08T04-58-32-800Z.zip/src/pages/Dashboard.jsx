const db = globalThis.__B44_DB__ || {
  auth: { isAuthenticated: async () => false, me: async () => null },
  entities: new Proxy({}, { get: () => ({ filter: async () => [], get: async () => null, create: async () => ({}), update: async () => ({}), delete: async () => ({}) }) }),
  integrations: { Core: { UploadFile: async () => ({ file_url: '' }) } }
};

import React, { useState, useEffect, useCallback } from "react";

import PlayerHeader from "@/components/lebron/PlayerHeader";
import StatsCards from "@/components/lebron/StatsCards";
import SeasonTable from "@/components/lebron/SeasonTable";
import MilestoneTracker from "@/components/lebron/MilestoneTracker";
import ScoringChart from "@/components/lebron/ScoringChart";
import SightingsMap from "@/components/lebron/SightingsMap";
import { RefreshCw } from "lucide-react";

const REFRESH_INTERVAL = 5 * 60 * 1000; // 5 minutes

export default function Dashboard() {
  const [liveData, setLiveData] = useState(null);
  const [lastUpdated, setLastUpdated] = useState(null);
  const [loading, setLoading] = useState(false);
  const [countdown, setCountdown] = useState(REFRESH_INTERVAL / 1000);

  const fetchLiveData = useCallback(async () => {
    setLoading(true);
    try {
      const data = await db.integrations.Core.InvokeLLM({
        prompt: `You are a LeBron James stats tracker. Return the most current/recent information about LeBron James as of today (2026). Include:
1. His current season stats (PPG, RPG, APG, SPG, BPG, FG%, 3P%, games played)
2. His total career points (most recent known figure)
3. His most recent game result (opponent, score, LeBron's stats)
4. A recent sighting or news headline about LeBron (where he was spotted or what he did recently - can be a game, restaurant, event, etc.)

Be accurate and use real data. For the sighting, include a specific real location with lat/lng coordinates.`,
        add_context_from_internet: true,
        response_json_schema: {
          type: "object",
          properties: {
            current_season: {
              type: "object",
              properties: {
                ppg: { type: "number" },
                rpg: { type: "number" },
                apg: { type: "number" },
                spg: { type: "number" },
                bpg: { type: "number" },
                fg_pct: { type: "string" },
                three_pct: { type: "string" },
                games_played: { type: "number" },
                season: { type: "string" }
              }
            },
            career_points: { type: "number" },
            last_game: {
              type: "object",
              properties: {
                opponent: { type: "string" },
                result: { type: "string" },
                points: { type: "number" },
                rebounds: { type: "number" },
                assists: { type: "number" },
                date: { type: "string" }
              }
            },
            latest_sighting: {
              type: "object",
              properties: {
                location: { type: "string" },
                description: { type: "string" },
                date: { type: "string" },
                lat: { type: "number" },
                lng: { type: "number" },
                emoji: { type: "string" }
              }
            }
          }
        }
      });
      setLiveData(data);
      setLastUpdated(new Date());
      setCountdown(REFRESH_INTERVAL / 1000);
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  }, []);

  // Initial fetch
  useEffect(() => {
    fetchLiveData();
  }, [fetchLiveData]);

  // Auto-refresh every 5 minutes
  useEffect(() => {
    const interval = setInterval(fetchLiveData, REFRESH_INTERVAL);
    return () => clearInterval(interval);
  }, [fetchLiveData]);

  // Countdown ticker
  useEffect(() => {
    const tick = setInterval(() => {
      setCountdown((c) => (c <= 1 ? REFRESH_INTERVAL / 1000 : c - 1));
    }, 1000);
    return () => clearInterval(tick);
  }, []);

  const formatCountdown = (s) => {
    const m = Math.floor(s / 60);
    const sec = s % 60;
    return `${m}:${String(sec).padStart(2, "0")}`;
  };

  return (
    <div className="min-h-screen bg-background">
      <div className="max-w-7xl mx-auto px-4 md:px-6 py-6 md:py-10 space-y-6">

        {/* Live status bar */}
        <div className="flex items-center justify-between text-xs text-muted-foreground bg-muted/30 rounded-lg px-4 py-2 border border-border">
          <div className="flex items-center gap-2">
            <span className={`w-2 h-2 rounded-full ${loading ? "bg-primary animate-pulse" : "bg-chart-4"}`} />
            <span>{loading ? "Fetching latest data..." : "Live Data"}</span>
            {lastUpdated && !loading && (
              <span>· Updated {lastUpdated.toLocaleTimeString()}</span>
            )}
          </div>
          <div className="flex items-center gap-3">
            {!loading && <span>Next refresh in {formatCountdown(countdown)}</span>}
            <button
              onClick={fetchLiveData}
              disabled={loading}
              className="flex items-center gap-1 text-primary hover:text-primary/80 disabled:opacity-40 transition-colors"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${loading ? "animate-spin" : ""}`} />
              Refresh
            </button>
          </div>
        </div>

        <PlayerHeader liveData={liveData} />
        <StatsCards liveData={liveData} />
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <ScoringChart liveData={liveData} />
          <MilestoneTracker />
        </div>
        <SeasonTable liveData={liveData} />
        <SightingsMap latestSighting={liveData?.latest_sighting} />

        <p className="text-center text-xs text-muted-foreground pb-4">
          Stats powered by AI · Auto-refreshes every 5 minutes
        </p>
      </div>
    </div>
  );
}